package dev.tunahanxx.utils;

import org.bukkit.Sound;

public class SoundUtils {
	
	public static Sound levelUp = Sound.ENTITY_PLAYER_LEVELUP;
	
	public static Sound villagerNo = Sound.ENTITY_VILLAGER_NO;
	
	public static Sound endermanTeleport = Sound.ENTITY_ENDERMAN_TELEPORT;
	
}